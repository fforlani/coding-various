public class Main {

    private static String input1 = "00-example.txt";
    private static String input2 = "00-example.txt";
    private static String input3 = "00-example.txt";
    private static String input4 = "00-example.txt";
    private static String input5 = "00-example.txt";

    public static void main(String[] args){
        new Game(input1);
    }
}
